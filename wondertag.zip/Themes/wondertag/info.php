<?php
$themeName = 'Wondertag';

$themeFolder = 'wondertag';

$themeAuthor = 'Kulvir Singh';

$themeAuthorUrl = 'https://bit.ly/k_97';

$themeVirsion = '2.4.1';

$themeImg = $themeFolder . '/themeLogo.png';
?>