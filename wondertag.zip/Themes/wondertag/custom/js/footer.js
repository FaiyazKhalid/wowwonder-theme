/* 

The code entered here will be added in <footer> tag 

*/